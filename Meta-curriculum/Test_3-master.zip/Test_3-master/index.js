/*
@author: Emad Bin Abid
@date: July 04, 2018
*/

//Application dependencies
    //custom dependencies
const server = require('./server');

    //npm dependencies
const express = require('express');
const PDFDocument = require('pdfkit');
const fs = require('fs');

const app = express();

//Middlewares
app.use(express.json());    //To parse json objects sent by the client.


app.get('/', (req, res) => {

    doc = new PDFDocument;

    doc.pipe(fs.createWriteStream('output.pdf'));

    //doc.font('fonts/PalatinoBold.ttf')
    doc.fontSize(25)
    doc.text('Some text with an embedded font!', 100, 100)

    doc.addPage()
    .fontSize(25)
    .text('Here is some vector graphics...', 100, 100)

    doc.save()
    .moveTo(100, 150)
    .lineTo(100, 250)
    .lineTo(200, 250)
    .fill("#FF3300")

    doc.scale(0.6)
    .translate(470, -380)
    .path('M 250,75 L 323,301 131,161 369,161 177,301 z')
    .fill('red', 'even-odd')
    .restore()

    doc.addPage()
    .fillColor("blue")
    .text('Here is a link!', 100, 100)
    .underline(100, 100, 160, 27, color= "#0000FF")
    .link(100, 100, 160, 27, 'http://google.com/')

    doc.pipe(res);
    doc.end()







    // const doc = new PDFDocument()
    // let filename = req.body.filename
    // // Stripping special characters
    // filename =  'sample.pdf'
    // // Setting response to 'attachment' (download).
    // // If you use 'inline' here it will automatically open the PDF
    // res.setHeader('Content-disposition', 'attachment; filename="' + filename + '"')
    // res.setHeader('Content-type', 'application/pdf');
    // // const content = 'Hello PDF';
    
    // var dd = {
    //     content: [
    //         'First paragraph',
    //         'Another paragraph, this time a little bit longer to make sure, this line will be divided into at least two lines'
    //     ]
        
    // }

    // doc.y = 300
    // doc.text(dd, 50, 50)
    // doc.pipe(res)
    // doc.end()
});


//Running the server
server.run(app, 3000);

