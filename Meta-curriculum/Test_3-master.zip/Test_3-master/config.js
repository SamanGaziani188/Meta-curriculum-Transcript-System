/*
@author: Emad Bin Abid
@date: July 04, 2018
*/

const jwt_key = exports.jwt_key = 'aQwgT1hLoMp';    //A random key